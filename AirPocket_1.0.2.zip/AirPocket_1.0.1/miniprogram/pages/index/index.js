Page({
  goFindBags() {
    wx.navigateTo({
      url: "/pages/many-bags/home/home",
    });
  },

  goOfferSpace() {
    wx.navigateTo({
      url: "/pages/empty-bag/home/home",
    });
  },
});
