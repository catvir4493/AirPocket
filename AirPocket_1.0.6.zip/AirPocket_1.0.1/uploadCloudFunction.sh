functions=(
  getOpenId
  createBag
  getBags
  getBagDetail
  bindBag
  updateBag
  getMyCarrierBags
  getMySenderBindings
)

for functionName in "${functions[@]}"; do
  ${installPath} cloud functions deploy --e ${envId} --n ${functionName} --r --project ${projectPath}
done
