const { formatDateTime, formatWeight } = require("../../../utils/format");

const statusLabels = {
  active: "可绑定",
  locked: "已锁定",
  closed: "已关闭",
  expired: "已过期",
};

const bindingStatusLabels = {
  pending: "等待确认",
  locked: "已锁单",
  contacted: "已联系",
  picked_up: "已取货",
  packed: "已打包",
  delivered_to_carrier: "已送至带货者",
  completed: "已完成",
  cancelled: "已取消",
};

Page({
  data: {
    loading: false,
    bags: [],
  },

  onShow() {
    this.fetchBags();
  },

  onPullDownRefresh() {
    this.fetchBags().finally(() => wx.stopPullDownRefresh());
  },

  async fetchBags() {
    this.setData({ loading: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "getMyCarrierBags",
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "加载失败");
      }
      const bags = (result.data || []).map((bag) => ({
        ...bag,
        isFullCase: bag.spaceType === "fullCase",
        spaceTypeText: bag.spaceType === "fullCase" ? "整箱" : "散件",
        totalWeightText: formatWeight(bag.totalWeight),
        remainingWeightText: formatWeight(bag.remainingWeight),
        boundWeightText: formatWeight(bag.boundWeight || 0),
        createdAtText: formatDateTime(bag.createdAt),
        statusText: statusLabels[bag.status] || bag.status,
        expanded: false,
        bindings: (bag.bindings || []).map((binding) => ({
          ...binding,
          spaceTypeText: binding.spaceType === "fullCase" ? "整箱" : "散件",
          requestedWeightText: formatWeight(binding.requestedWeight),
          createdAtText: formatDateTime(binding.createdAt),
          statusText: bindingStatusLabels[binding.status] || binding.status,
        })),
      }));
      this.setData({
        bags: bags.map((bag) => ({
          ...bag,
          canEdit: !bag.bindingCount,
        })),
      });
    } catch (error) {
      wx.showToast({
        title: error.message || "加载失败",
        icon: "none",
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  toggleBindings(event) {
    const { index } = event.currentTarget.dataset;
    this.setData({
      [`bags[${index}].expanded`]: !this.data.bags[index].expanded,
    });
  },

  editBag(event) {
    const { id } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/offer-space/edit/edit?id=${id}`,
    });
  },

  goAppHome() {
    wx.reLaunch({
      url: "/pages/index/index",
    });
  },

  goOfferSpace() {
    wx.navigateTo({
      url: "/pages/offer-space/home/home",
    });
  },
});
