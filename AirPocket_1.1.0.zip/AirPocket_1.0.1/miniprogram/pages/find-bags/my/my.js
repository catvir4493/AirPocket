const { formatDateTime, formatWeight, toDate } = require("../../../utils/format");
const { formatSpecialItems } = require("../../../utils/specialItems");

const statusLabels = {
  pending: "等待确认",
  locked: "已锁单",
  contacted: "已联系",
  picked_up: "已取货",
  packed: "已打包",
  delivered_to_carrier: "已送至带货者",
  completed: "已完成",
  cancelled: "已取消",
};

const getEditState = (binding) => {
  const lockDeadlineAt = toDate(binding.lockDeadlineAt);
  const now = new Date();
  const canEdit =
    binding.status === "pending" && lockDeadlineAt && lockDeadlineAt.getTime() > now.getTime();

  if (canEdit) {
    const remainingMinutes = Math.max(
      1,
      Math.ceil((lockDeadlineAt.getTime() - now.getTime()) / 60000)
    );
    return {
      canEdit: true,
      lockText: `可编辑，剩余 ${remainingMinutes} 分钟`,
    };
  }

  if (binding.status === "cancelled") {
    return {
      canEdit: false,
      lockText: "已取消",
    };
  }

  return {
    canEdit: false,
    lockText: binding.status === "pending" ? "锁单信息待同步" : "已锁单，需联系平台修改",
  };
};

Page({
  data: {
    loading: false,
    cancelling: false,
    bindings: [],
  },

  onShow() {
    this.fetchBindings();
  },

  onPullDownRefresh() {
    this.fetchBindings().finally(() => wx.stopPullDownRefresh());
  },

  async fetchBindings() {
    this.setData({ loading: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "getMySenderBindings",
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "加载失败");
      }
      const bindings = (result.data || []).map((binding) => ({
        ...binding,
        ...getEditState(binding),
        spaceTypeText: binding.spaceType === "fullCase" ? "整箱" : "散件",
        requestedCasesText: `${Number(binding.requestedCases || (binding.spaceType === "fullCase" ? 1 : 0))} 件`,
        requestedWeightText: formatWeight(binding.requestedWeight),
        requestedSpecialItemsText: formatSpecialItems(binding.requestedSpecialItems),
        listSummary: `${binding.departureDate || "-"}   ${binding.fromCity || "-"} - ${binding.toCity || "-"}`,
        createdAtText: formatDateTime(binding.createdAt),
        lockDeadlineText: formatDateTime(binding.lockDeadlineAt),
        lockedAtText: formatDateTime(binding.lockedAt),
        statusText: statusLabels[binding.status] || binding.status,
      }));
      this.setData({ bindings });
    } catch (error) {
      wx.showToast({
        title: error.message || "加载失败",
        icon: "none",
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  goAppHome() {
    wx.reLaunch({
      url: "/pages/index/index",
    });
  },

  goFindBags() {
    wx.navigateTo({
      url: "/pages/find-bags/home/home",
    });
  },

  goEditBinding(event) {
    const { id } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/find-bags/edit/edit?id=${id}`,
    });
  },

  cancelBinding(event) {
    const { id } = event.currentTarget.dataset;
    if (this.data.cancelling) {
      return;
    }

    wx.showModal({
      title: "取消绑定",
      content: "取消后会释放已占用重量，确认取消这条绑定吗？",
      confirmText: "取消绑定",
      cancelText: "再想想",
      success: async (modalRes) => {
        if (!modalRes.confirm) {
          return;
        }

        this.setData({ cancelling: true });
        wx.showLoading({
          title: "取消中",
          mask: true,
        });

        try {
          const resp = await wx.cloud.callFunction({
            name: "cancelBinding",
            data: {
              bindingId: id,
            },
          });
          const result = resp.result || {};
          if (!result.success) {
            throw new Error(result.errMsg || "取消失败");
          }
          wx.showToast({
            title: "已取消",
            icon: "success",
          });
          this.fetchBindings();
        } catch (error) {
          wx.showToast({
            title: error.message || "取消失败",
            icon: "none",
          });
        } finally {
          wx.hideLoading();
          this.setData({ cancelling: false });
        }
      },
    });
  },
});
