Page({
  goReleaseBag() {
    wx.navigateTo({
      url: "/pages/empty-bag/release/release",
    });
  },

  goMyBags() {
    wx.navigateTo({
      url: "/pages/empty-bag/my/my",
    });
  },
});
