const { formatDateTime, formatWeight } = require("../../../utils/format");

const statusLabels = {
  active: "可绑定",
  locked: "已锁定",
  closed: "已关闭",
  expired: "已过期",
};

Page({
  data: {
    loading: false,
    bags: [],
  },

  onShow() {
    this.fetchBags();
  },

  onPullDownRefresh() {
    this.fetchBags().finally(() => wx.stopPullDownRefresh());
  },

  async fetchBags() {
    this.setData({ loading: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "getMyCarrierBags",
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "加载失败");
      }
      const bags = (result.data || []).map((bag) => ({
        ...bag,
        totalWeightText: formatWeight(bag.totalWeight),
        remainingWeightText: formatWeight(bag.remainingWeight),
        boundWeightText: formatWeight(bag.boundWeight || 0),
        createdAtText: formatDateTime(bag.createdAt),
        statusText: statusLabels[bag.status] || bag.status,
        expanded: false,
        bindings: (bag.bindings || []).map((binding) => ({
          ...binding,
          requestedWeightText: formatWeight(binding.requestedWeight),
          createdAtText: formatDateTime(binding.createdAt),
        })),
      }));
      this.setData({ bags });
    } catch (error) {
      wx.showToast({
        title: error.message || "加载失败",
        icon: "none",
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  toggleBindings(event) {
    const { index } = event.currentTarget.dataset;
    this.setData({
      [`bags[${index}].expanded`]: !this.data.bags[index].expanded,
    });
  },

  goHome() {
    wx.navigateTo({
      url: "/pages/offer-space/home/home",
    });
  },

  goReleaseBag() {
    wx.navigateTo({
      url: "/pages/offer-space/release/release",
    });
  },
});
