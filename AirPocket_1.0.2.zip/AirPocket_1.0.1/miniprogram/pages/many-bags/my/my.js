const { formatDateTime, formatWeight } = require("../../../utils/format");

const statusLabels = {
  pending: "等待确认",
  confirmed: "已确认",
  rejected: "已拒绝",
  completed: "已完成",
  cancelled: "已取消",
};

Page({
  data: {
    loading: false,
    bindings: [],
  },

  onShow() {
    this.fetchBindings();
  },

  onPullDownRefresh() {
    this.fetchBindings().finally(() => wx.stopPullDownRefresh());
  },

  async fetchBindings() {
    this.setData({ loading: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "getMySenderBindings",
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "加载失败");
      }
      const bindings = (result.data || []).map((binding) => ({
        ...binding,
        requestedWeightText: formatWeight(binding.requestedWeight),
        createdAtText: formatDateTime(binding.createdAt),
        statusText: statusLabels[binding.status] || binding.status,
      }));
      this.setData({ bindings });
    } catch (error) {
      wx.showToast({
        title: error.message || "加载失败",
        icon: "none",
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  goHome() {
    wx.navigateTo({
      url: "/pages/many-bags/home/home",
    });
  },

  goDetailTip() {
    wx.showToast({
      title: "请先选择一个可用行李额",
      icon: "none",
    });
  },
});
