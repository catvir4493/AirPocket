const cloud = require("wx-server-sdk");

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();

const BOOTSTRAP_ADMINS = [
  {
    openid: "oX_k43eAhymzTcpvZzBVOu2laQEw",
    name: "Owner",
    role: "admin",
  },
  {
    openid: "oX_k43YqzUg6Qae_29yHgsUWL3VY",
    name: "Admin Friend",
    role: "admin",
  },
];

const toMessage = (error) => `${error.message || error.errMsg || error}`;

const isCollectionMissing = (error) =>
  toMessage(error).toLowerCase().includes("not exist");

const getBootstrapAdmins = () => {
  const envAdmins = `${process.env.ADMIN_OPENIDS || ""}`
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean)
    .map((openid) => ({
      openid,
      name: "Env Admin",
      role: "admin",
    }));
  return BOOTSTRAP_ADMINS.concat(envAdmins);
};

const findBootstrapAdmin = (openid) =>
  getBootstrapAdmins().find((admin) => admin.openid === openid);

const ensureAdminsCollection = async () => {
  try {
    await db.createCollection("admins");
  } catch (error) {
    // Collection already exists in normal operation.
  }
};

const getAdminRecord = async (openid) => {
  try {
    const result = await db
      .collection("admins")
      .where({
        openid,
      })
      .limit(1)
      .get();
    return result.data[0] || null;
  } catch (error) {
    if (isCollectionMissing(error)) {
      return null;
    }
    throw error;
  }
};

const createBootstrapAdmin = async (openid, admin) => {
  await ensureAdminsCollection();
  const now = new Date();
  const record = {
    openid,
    name: admin.name || "Admin",
    role: admin.role || "admin",
    status: "active",
    source: "bootstrap",
    createdAt: now,
    updatedAt: now,
  };
  await db.collection("admins").add({
    data: record,
  });
  return record;
};

const getAdminAccess = async (openid) => {
  if (!openid) {
    return null;
  }

  const adminRecord = await getAdminRecord(openid);
  if (adminRecord) {
    return adminRecord.status === "active" ? adminRecord : null;
  }

  const bootstrapAdmin = findBootstrapAdmin(openid);
  if (!bootstrapAdmin) {
    return null;
  }

  return await createBootstrapAdmin(openid, bootstrapAdmin);
};

exports.main = async () => {
  try {
    const { OPENID } = cloud.getWXContext();
    const admin = await getAdminAccess(OPENID);

    return {
      success: true,
      data: {
        isAdmin: Boolean(admin),
        openid: OPENID || "",
        admin: admin
          ? {
              name: admin.name || "",
              role: admin.role || "admin",
              status: admin.status || "active",
            }
          : null,
      },
    };
  } catch (error) {
    return {
      success: true,
      data: {
        isAdmin: false,
        openid: "",
        admin: null,
      },
    };
  }
};
