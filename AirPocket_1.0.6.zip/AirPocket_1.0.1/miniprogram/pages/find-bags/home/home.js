const { formatDateTime, formatWeight } = require("../../../utils/format");

Page({
  data: {
    loading: false,
    bags: [],
  },

  onShow() {
    this.fetchBags();
  },

  onPullDownRefresh() {
    this.fetchBags().finally(() => wx.stopPullDownRefresh());
  },

  async fetchBags() {
    this.setData({ loading: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "getBags",
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "加载失败");
      }
      const bags = (result.data || []).map((bag) => ({
        ...bag,
        isFullCase: bag.spaceType === "fullCase",
        spaceTypeText: bag.spaceType === "fullCase" ? "整箱" : "散件",
        weightSummary: bag.spaceType === "fullCase" ? "整箱默认 23 kg" : `${formatWeight(bag.remainingWeight)} left`,
        remainingWeightText: formatWeight(bag.remainingWeight),
        totalWeightText: formatWeight(bag.totalWeight),
        createdAtText: formatDateTime(bag.createdAt),
      }));
      this.setData({ bags });
    } catch (error) {
      wx.showToast({
        title: error.message || "加载失败",
        icon: "none",
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  openDetail(event) {
    const { id } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/find-bags/detail/detail?id=${id}`,
    });
  },

  goAppHome() {
    wx.reLaunch({
      url: "/pages/index/index",
    });
  },

  goMyBags() {
    wx.navigateTo({
      url: "/pages/find-bags/my/my",
    });
  },
});
