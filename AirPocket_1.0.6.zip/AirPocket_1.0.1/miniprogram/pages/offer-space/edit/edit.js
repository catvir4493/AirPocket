const today = () => {
  const date = new Date();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  return `${date.getFullYear()}-${month < 10 ? `0${month}` : month}-${day < 10 ? `0${day}` : day}`;
};

const listToText = (value) => (Array.isArray(value) ? value.join(", ") : "");

const isPastDate = (value, minDate) => value && value < minDate;

Page({
  data: {
    bagId: "",
    loading: false,
    submitting: false,
    minDate: today(),
    form: {
      spaceType: "loose",
      fromCity: "",
      toCity: "",
      departureDate: "",
      flightNo: "",
      totalWeight: "",
      availableVolume: "",
      allowedItemsText: "",
      restrictedItemsText: "",
      note: "",
    },
  },

  onLoad(options) {
    if (!options.id) {
      wx.showToast({
        title: "缺少 bag 信息",
        icon: "none",
      });
      return;
    }
    this.setData({ bagId: options.id });
    this.fetchBag(options.id);
  },

  async fetchBag(bagId) {
    this.setData({ loading: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "getBagDetail",
        data: { bagId },
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "加载失败");
      }

      const bag = result.data;
      const spaceType = bag.spaceType === "fullCase" ? "fullCase" : "loose";
      this.setData({
        form: {
          spaceType,
          fromCity: bag.fromCity || "",
          toCity: bag.toCity || "",
          departureDate: bag.departureDate || "",
          flightNo: bag.flightNo || "",
          totalWeight: spaceType === "fullCase" ? "" : `${bag.totalWeight || ""}`,
          availableVolume: bag.availableVolume || "",
          allowedItemsText: listToText(bag.allowedItems),
          restrictedItemsText: listToText(bag.restrictedItems),
          note: bag.note || "",
        },
      });
    } catch (error) {
      wx.showToast({
        title: error.message || "加载失败",
        icon: "none",
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  onFieldInput(event) {
    const { field } = event.currentTarget.dataset;
    this.setData({
      [`form.${field}`]: event.detail.value,
    });
  },

  selectSpaceType(event) {
    const { type } = event.currentTarget.dataset;
    this.setData({
      "form.spaceType": type,
      "form.totalWeight": type === "fullCase" ? "" : this.data.form.totalWeight,
    });
  },

  onDateChange(event) {
    this.setData({
      "form.departureDate": event.detail.value,
    });
  },

  validateForm() {
    const { form, minDate } = this.data;
    const required = [
      ["fromCity", "请填写出发城市"],
      ["toCity", "请填写到达城市"],
      ["departureDate", "请选择出发日期"],
    ];

    for (let i = 0; i < required.length; i += 1) {
      const [field, message] = required[i];
      if (!`${form[field]}`.trim()) {
        return message;
      }
    }

    if (isPastDate(form.departureDate, minDate)) {
      return "出发日期不能早于今天";
    }

    if (form.spaceType === "fullCase") {
      return "";
    }

    if (!`${form.totalWeight}`.trim()) {
      return "请填写可用重量";
    }

    const totalWeight = Number(form.totalWeight);
    if (!Number.isFinite(totalWeight) || totalWeight <= 0) {
      return "可用重量必须大于 0";
    }
    return "";
  },

  async submitBag() {
    if (this.data.submitting) {
      return;
    }

    const errorMessage = this.validateForm();
    if (errorMessage) {
      wx.showToast({
        title: errorMessage,
        icon: "none",
      });
      return;
    }

    const { bagId, form } = this.data;
    this.setData({ submitting: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "updateBag",
        data: {
          bagId,
          ...form,
          totalWeight: form.spaceType === "fullCase" ? 23 : Number(form.totalWeight),
        },
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "更新失败");
      }
      wx.showToast({
        title: "已更新",
        icon: "success",
      });
      setTimeout(() => {
        wx.redirectTo({
          url: "/pages/offer-space/my/my",
        });
      }, 700);
    } catch (error) {
      wx.showToast({
        title: error.message || "更新失败",
        icon: "none",
      });
    } finally {
      this.setData({ submitting: false });
    }
  },
});
