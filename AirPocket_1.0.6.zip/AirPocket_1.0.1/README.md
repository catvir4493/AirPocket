# AirPocket MVP

AirPocket 是一个面向中匈跨境留学生、旅行者和华人用户的 P2P 行李额共享微信小程序 MVP。这里的 bag 指空余行李额 / 可被别人使用的行李空间。

## 已实现链路

- 带货者进入 `Offer Space`，通过 `Release Bag` 发布新的空余行李额，系统生成 `A0001` 格式的 bagNo。
- 寄货者进入 `Find Bags`，查看 active 且剩余重量大于 0 的 bag。
- 寄货者进入详情页填写占用重量和物品描述，调用云函数完成绑定。
- 绑定后扣减 `bags.remainingWeight`，剩余重量为 0 时自动把 bag 状态更新为 `locked`。
- 带货者和寄货者分别在各自模块的 `My Bags` 查看历史记录。

## 云函数

需要在微信开发者工具中上传并部署以下云函数，建议选择“上传并部署：云端安装依赖”：

- `getOpenId`
- `createBag`
- `getBags`
- `getBagDetail`
- `bindBag`
- `updateBag`
- `getMyCarrierBags`
- `getMySenderBindings`

`createBag` 会尝试自动创建 `bags` 和 `counters` collection；`bindBag` 会尝试自动创建 `bindings` collection。

`Release Bag` 支持 `散件` 和 `整箱` 两种类型：散件由带货者填写可用重量；整箱默认 23kg，寄货者绑定时不能改重量。未被绑定过的 bag 可以在带货者 `My Bags` 中进入 `Edit Bag / 编辑` 修改全部发布信息，包括散件和整箱互转。

## 暂未接入

- 微信支付
- 聊天功能
- 实名认证
