const cloud = require("wx-server-sdk");

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();

const normalizeList = (value) => {
  if (Array.isArray(value)) {
    return value.map((item) => `${item}`.trim()).filter(Boolean);
  }
  return `${value || ""}`
    .split(/[,，\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
};

const fail = (errMsg) => ({
  success: false,
  errMsg,
});

const todayYmd = () => new Date().toISOString().slice(0, 10);

const isValidDateText = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value);

const ensureCollection = async (name) => {
  try {
    await db.createCollection(name);
  } catch (error) {
    // Existing collections throw here; that is fine for this MVP bootstrap.
  }
};

exports.main = async (event = {}) => {
  const wxContext = cloud.getWXContext();
  const carrierId = wxContext.OPENID;
  const spaceType = event.spaceType === "fullCase" ? "fullCase" : "loose";
  const totalWeight = spaceType === "fullCase" ? 23 : Number(event.totalWeight);
  const departureDate = `${event.departureDate || ""}`.trim();

  if (!carrierId) {
    return fail("Unable to identify current user");
  }
  if (!event.bagId) {
    return fail("bagId is required");
  }
  if (!`${event.fromCity || ""}`.trim()) {
    return fail("fromCity is required");
  }
  if (!`${event.toCity || ""}`.trim()) {
    return fail("toCity is required");
  }
  if (!`${event.carrierWechat || ""}`.trim()) {
    return fail("carrierWechat is required");
  }
  if (!`${event.carrierReceiveAddress || ""}`.trim()) {
    return fail("carrierReceiveAddress is required");
  }
  if (!departureDate) {
    return fail("departureDate is required");
  }
  if (!isValidDateText(departureDate) || departureDate < todayYmd()) {
    return fail("departureDate cannot be earlier than today");
  }
  if (!Number.isFinite(totalWeight) || totalWeight <= 0) {
    return fail("totalWeight must be greater than 0");
  }

  try {
    await ensureCollection("bindings");

    const result = await db.runTransaction(async (transaction) => {
      const bagResult = await transaction.collection("bags").doc(event.bagId).get();
      const bag = bagResult.data;

      if (!bag) {
        throw new Error("Bag not found");
      }
      if (bag.carrierId !== carrierId) {
        throw new Error("No permission to update this bag");
      }

      const bindingResult = await transaction
        .collection("bindings")
        .where({ bagId: event.bagId })
        .limit(1)
        .get();

      if ((bindingResult.data || []).length > 0) {
        throw new Error("This bag already has bindings");
      }

      const now = new Date();
      const updateData = {
        fromCity: `${event.fromCity || ""}`.trim(),
        toCity: `${event.toCity || ""}`.trim(),
        departureDate,
        flightNo: `${event.flightNo || ""}`.trim(),
        carrierWechat: `${event.carrierWechat || ""}`.trim(),
        carrierReceiveAddress: `${event.carrierReceiveAddress || ""}`.trim(),
        spaceType,
        totalWeight,
        remainingWeight: totalWeight,
        availableVolume: `${event.availableVolume || ""}`.trim(),
        allowedItems: normalizeList(event.allowedItems || event.allowedItemsText),
        restrictedItems: normalizeList(event.restrictedItems || event.restrictedItemsText),
        note: `${event.note || ""}`.trim(),
        status: "active",
        updatedAt: now,
      };

      await transaction.collection("bags").doc(event.bagId).update({
        data: updateData,
      });

      return {
        success: true,
        data: {
          _id: event.bagId,
          ...bag,
          ...updateData,
        },
      };
    });

    return result;
  } catch (error) {
    return fail(error.message || "updateBag failed");
  }
};
