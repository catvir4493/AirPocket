const { formatDateTime, formatWeight } = require("../../../utils/format");

Page({
  data: {
    loading: false,
    bags: [],
  },

  onShow() {
    this.fetchBags();
  },

  onPullDownRefresh() {
    this.fetchBags().finally(() => wx.stopPullDownRefresh());
  },

  async fetchBags() {
    this.setData({ loading: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "getBags",
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "加载失败");
      }
      const bags = (result.data || []).map((bag) => {
        const isFullCase = bag.spaceType === "fullCase";
        const remainingCases = Number.isFinite(Number(bag.remainingCases))
          ? Number(bag.remainingCases)
          : Math.floor(Number(bag.remainingWeight || 0) / 23);
        const caseCount = Number.isFinite(Number(bag.caseCount))
          ? Number(bag.caseCount)
          : remainingCases || 1;
        return {
          ...bag,
          isFullCase,
          spaceTypeText: isFullCase ? "整箱" : "散件",
          caseCountText: `${caseCount} 件`,
          remainingCasesText: `${remainingCases} 件`,
          weightSummary: isFullCase
            ? `${remainingCases} cases left · 23 kg each`
            : `${formatWeight(bag.remainingWeight)} left`,
          remainingWeightText: formatWeight(bag.remainingWeight),
          totalWeightText: formatWeight(bag.totalWeight),
          createdAtText: formatDateTime(bag.createdAt),
        };
      });
      this.setData({ bags });
    } catch (error) {
      wx.showToast({
        title: error.message || "加载失败",
        icon: "none",
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  openDetail(event) {
    const { id } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/find-bags/detail/detail?id=${id}`,
    });
  },

  goAppHome() {
    wx.reLaunch({
      url: "/pages/index/index",
    });
  },

  goMyBags() {
    wx.navigateTo({
      url: "/pages/find-bags/my/my",
    });
  },
});
