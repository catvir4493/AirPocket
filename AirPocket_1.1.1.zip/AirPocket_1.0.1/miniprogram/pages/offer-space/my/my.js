Page({
  data: {
    loading: false,
    bags: [],
  },

  onShow() {
    this.fetchBags();
  },

  onPullDownRefresh() {
    this.fetchBags().finally(() => wx.stopPullDownRefresh());
  },

  async fetchBags() {
    this.setData({ loading: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "getMyCarrierBags",
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "加载失败");
      }

      const bags = (result.data || []).map((bag) => ({
        ...bag,
        listDateText: bag.departureDate || "-",
        listRouteText: `${bag.fromCity || "-"} - ${bag.toCity || "-"}`,
      }));

      this.setData({ bags });
    } catch (error) {
      wx.showToast({
        title: error.message || "加载失败",
        icon: "none",
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  openBagDetail(event) {
    const { id } = event.currentTarget.dataset;
    if (!id) {
      return;
    }

    wx.navigateTo({
      url: `/pages/offer-space/bag-detail/detail?id=${id}`,
    });
  },

  goAppHome() {
    wx.reLaunch({
      url: "/pages/index/index",
    });
  },

  goOfferSpace() {
    wx.navigateTo({
      url: "/pages/offer-space/home/home",
    });
  },
});
