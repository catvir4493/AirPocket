const cloud = require("wx-server-sdk");

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();

const isCollectionMissing = (error) =>
  `${error.message || error.errMsg || error}`.toLowerCase().includes("not exist");

exports.main = async () => {
  const wxContext = cloud.getWXContext();
  const senderId = wxContext.OPENID;

  if (!senderId) {
    return {
      success: false,
      errMsg: "Unable to identify current user",
    };
  }

  try {
    const result = await db
      .collection("bindings")
      .where({ senderId })
      .orderBy("createdAt", "desc")
      .limit(100)
      .get();

    return {
      success: true,
      data: result.data,
    };
  } catch (error) {
    if (isCollectionMissing(error)) {
      return {
        success: true,
        data: [],
      };
    }
    return {
      success: false,
      errMsg: error.message || "getMySenderBindings failed",
    };
  }
};
