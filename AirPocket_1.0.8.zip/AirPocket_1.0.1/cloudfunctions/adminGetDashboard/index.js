const cloud = require("wx-server-sdk");

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();
const _ = db.command;

const ADMIN_OPENIDS = ["oX_k43eAhymzTcpvZzBVOu2laQEw"];

const fail = (errMsg) => ({
  success: false,
  errMsg,
});

const isCollectionMissing = (error) =>
  `${error.message || error.errMsg || error}`.toLowerCase().includes("not exist");

const getAdminOpenids = () => {
  const envOpenids = `${process.env.ADMIN_OPENIDS || ""}`
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  return ADMIN_OPENIDS.concat(envOpenids).filter(
    (openid) => openid && openid !== "oX_k43eAhymzTcpvZzBVOu2laQEw"
  );
};

const assertAdmin = () => {
  const { OPENID } = cloud.getWXContext();
  const adminOpenids = getAdminOpenids();
  if (!adminOpenids.includes(OPENID)) {
    throw new Error("Admin permission required");
  }
  return OPENID;
};

exports.main = async () => {
  try {
    assertAdmin();

    const bagResult = await db
      .collection("bags")
      .orderBy("departureDate", "asc")
      .orderBy("createdAt", "desc")
      .limit(100)
      .get();

    const bags = bagResult.data || [];
    const bagIds = bags.map((bag) => bag._id).filter(Boolean);
    let bindings = [];

    if (bagIds.length) {
      try {
        const bindingResult = await db
          .collection("bindings")
          .where({
            bagId: _.in(bagIds),
          })
          .orderBy("createdAt", "desc")
          .limit(500)
          .get();
        bindings = bindingResult.data || [];
      } catch (error) {
        if (!isCollectionMissing(error)) {
          throw error;
        }
      }
    }

    const bindingsByBag = bindings.reduce((map, binding) => {
      if (!map[binding.bagId]) {
        map[binding.bagId] = [];
      }
      map[binding.bagId].push(binding);
      return map;
    }, {});

    const data = bags.map((bag) => {
      const bagBindings = bindingsByBag[bag._id] || [];
      const boundWeight = bagBindings.reduce(
        (sum, binding) => sum + Number(binding.requestedWeight || 0),
        0
      );
      return {
        ...bag,
        bindings: bagBindings,
        bindingCount: bagBindings.length,
        boundWeight: Math.round(boundWeight * 100) / 100,
      };
    });

    return {
      success: true,
      data,
      summary: {
        bagCount: bags.length,
        bindingCount: bindings.length,
      },
    };
  } catch (error) {
    if (isCollectionMissing(error)) {
      return {
        success: true,
        data: [],
        summary: {
          bagCount: 0,
          bindingCount: 0,
        },
      };
    }
    return fail(error.message || "adminGetDashboard failed");
  }
};
