const today = () => {
  const date = new Date();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  return `${date.getFullYear()}-${month < 10 ? `0${month}` : month}-${day < 10 ? `0${day}` : day}`;
};

const isPastDate = (value, minDate) => value && value < minDate;

Page({
  data: {
    submitting: false,
    minDate: today(),
    form: {
      spaceType: "loose",
      fromCity: "",
      toCity: "",
      departureDate: "",
      flightNo: "",
      carrierWechat: "",
      carrierReceiveAddress: "",
      totalWeight: "",
      availableVolume: "",
      allowedItemsText: "",
      restrictedItemsText: "",
      note: "",
    },
  },

  onFieldInput(event) {
    const { field } = event.currentTarget.dataset;
    this.setData({
      [`form.${field}`]: event.detail.value,
    });
  },

  selectSpaceType(event) {
    const { type } = event.currentTarget.dataset;
    this.setData({
      "form.spaceType": type,
      "form.totalWeight": type === "fullCase" ? "" : this.data.form.totalWeight,
    });
  },

  onDateChange(event) {
    this.setData({
      "form.departureDate": event.detail.value,
    });
  },

  validateForm() {
    const { form } = this.data;
    const required = [
      ["fromCity", "请填写出发城市"],
      ["toCity", "请填写到达城市"],
      ["carrierWechat", "请填写微信号"],
      ["carrierReceiveAddress", "请填写收货地址"],
      ["departureDate", "请选择出发日期"],
    ];
    for (let i = 0; i < required.length; i += 1) {
      const [field, message] = required[i];
      if (!`${form[field]}`.trim()) {
        return message;
      }
    }

    if (isPastDate(form.departureDate, this.data.minDate)) {
      return "出发日期不能早于今天";
    }

    if (form.spaceType === "fullCase") {
      return "";
    }

    if (!`${form.totalWeight}`.trim()) {
      return "请填写可用重量";
    }

    const totalWeight = Number(form.totalWeight);
    if (!Number.isFinite(totalWeight) || totalWeight <= 0) {
      return "可用重量必须大于 0";
    }
    return "";
  },

  async submitBag() {
    if (this.data.submitting) {
      return;
    }

    const errorMessage = this.validateForm();
    if (errorMessage) {
      wx.showToast({
        title: errorMessage,
        icon: "none",
      });
      return;
    }

    const { form } = this.data;
    this.setData({ submitting: true });
    try {
      const resp = await wx.cloud.callFunction({
        name: "createBag",
        data: {
          ...form,
          totalWeight: form.spaceType === "fullCase" ? 23 : Number(form.totalWeight),
        },
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "发布失败");
      }
      wx.showToast({
        title: `${result.data.bagNo} 已发布`,
        icon: "success",
      });
      setTimeout(() => {
        wx.redirectTo({
          url: "/pages/offer-space/my/my",
        });
      }, 800);
    } catch (error) {
      wx.showToast({
        title: error.message || "发布失败",
        icon: "none",
      });
    } finally {
      this.setData({ submitting: false });
    }
  },
});
