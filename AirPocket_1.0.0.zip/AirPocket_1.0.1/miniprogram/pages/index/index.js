Page({
  goManyBags() {
    wx.navigateTo({
      url: "/pages/many-bags/home/home",
    });
  },

  goEmptyBag() {
    wx.navigateTo({
      url: "/pages/empty-bag/home/home",
    });
  },
});
