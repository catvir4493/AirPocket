const cloud = require("wx-server-sdk");

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();

const fail = (errMsg) => ({
  success: false,
  errMsg,
});

const ensureCollection = async (name) => {
  try {
    await db.createCollection(name);
  } catch (error) {
    // Existing collections throw here; that is fine for this MVP bootstrap.
  }
};

exports.main = async (event = {}) => {
  const wxContext = cloud.getWXContext();
  const senderId = wxContext.OPENID;
  const requestedWeight = Number(event.requestedWeight);

  if (!senderId) {
    return fail("Unable to identify current user");
  }
  if (!event.bagId) {
    return fail("bagId is required");
  }
  if (!Number.isFinite(requestedWeight) || requestedWeight <= 0) {
    return fail("Requested weight must be greater than 0");
  }
  if (!`${event.itemDescription || ""}`.trim()) {
    return fail("itemDescription is required");
  }

  try {
    await ensureCollection("bindings");

    const result = await db.runTransaction(async (transaction) => {
      const bagResult = await transaction.collection("bags").doc(event.bagId).get();
      const bag = bagResult.data;

      if (!bag) {
        throw new Error("Bag not found");
      }
      if (bag.status !== "active") {
        throw new Error("This bag is not available");
      }

      const remainingWeight = Number(bag.remainingWeight);
      if (!Number.isFinite(remainingWeight) || requestedWeight > remainingWeight) {
        throw new Error("Requested weight exceeds remaining weight");
      }

      const now = new Date();
      const newRemainingWeight = Math.max(
        0,
        Math.round((remainingWeight - requestedWeight) * 100) / 100
      );
      const nextStatus = newRemainingWeight <= 0 ? "locked" : "active";

      const bindingData = {
        bagId: bag._id,
        bagNo: bag.bagNo,
        senderId,
        senderNickname: `${event.senderNickname || ""}`.trim(),
        carrierId: bag.carrierId,
        fromCity: bag.fromCity,
        toCity: bag.toCity,
        departureDate: bag.departureDate,
        requestedWeight,
        itemDescription: `${event.itemDescription || ""}`.trim(),
        senderNote: `${event.senderNote || ""}`.trim(),
        status: "pending",
        createdAt: now,
        updatedAt: now,
      };

      const bindingResult = await transaction.collection("bindings").add({
        data: bindingData,
      });

      await transaction.collection("bags").doc(event.bagId).update({
        data: {
          remainingWeight: newRemainingWeight,
          status: nextStatus,
          updatedAt: now,
        },
      });

      return {
        success: true,
        data: {
          bindingId: bindingResult._id,
          remainingWeight: newRemainingWeight,
          status: nextStatus,
        },
      };
    });

    return result;
  } catch (error) {
    return fail(error.message || "bindBag failed");
  }
};
