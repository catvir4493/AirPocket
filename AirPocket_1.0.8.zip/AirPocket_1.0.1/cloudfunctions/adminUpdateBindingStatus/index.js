const cloud = require("wx-server-sdk");

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();

const BOOTSTRAP_ADMINS = [
  {
    openid: "oX_k43eAhymzTcpvZzBVOu2laQEw",
    name: "Owner",
    role: "admin",
  },
  {
    openid: "oX_k43YqzUg6Qae_29yHgsUWL3VY",
    name: "Admin Friend",
    role: "admin",
  },
];
const BINDING_STATUSES = [
  "pending",
  "contacted",
  "picked_up",
  "packed",
  "delivered_to_carrier",
  "completed",
  "cancelled",
];

const fail = (errMsg) => ({
  success: false,
  errMsg,
});

const toMessage = (error) => `${error.message || error.errMsg || error}`;

const isCollectionMissing = (error) =>
  toMessage(error).toLowerCase().includes("not exist");

const getBootstrapAdmins = () => {
  const envAdmins = `${process.env.ADMIN_OPENIDS || ""}`
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean)
    .map((openid) => ({
      openid,
      name: "Env Admin",
      role: "admin",
    }));
  return BOOTSTRAP_ADMINS.concat(envAdmins);
};

const findBootstrapAdmin = (openid) =>
  getBootstrapAdmins().find((admin) => admin.openid === openid);

const ensureAdminsCollection = async () => {
  try {
    await db.createCollection("admins");
  } catch (error) {
    // Collection already exists in normal operation.
  }
};

const getAdminRecord = async (openid) => {
  try {
    const result = await db
      .collection("admins")
      .where({
        openid,
      })
      .limit(1)
      .get();
    return result.data[0] || null;
  } catch (error) {
    if (isCollectionMissing(error)) {
      return null;
    }
    throw error;
  }
};

const createBootstrapAdmin = async (openid, admin) => {
  await ensureAdminsCollection();
  const now = new Date();
  await db.collection("admins").add({
    data: {
      openid,
      name: admin.name || "Admin",
      role: admin.role || "admin",
      status: "active",
      source: "bootstrap",
      createdAt: now,
      updatedAt: now,
    },
  });
};

const assertAdmin = async () => {
  const { OPENID } = cloud.getWXContext();
  if (!OPENID) {
    throw new Error("Admin permission required");
  }

  const adminRecord = await getAdminRecord(OPENID);
  if (adminRecord) {
    if (adminRecord.status !== "active") {
      throw new Error("Admin permission required");
    }
    return OPENID;
  }

  const bootstrapAdmin = findBootstrapAdmin(OPENID);
  if (!bootstrapAdmin) {
    throw new Error("Admin permission required");
  }

  await createBootstrapAdmin(OPENID, bootstrapAdmin);
  return OPENID;
};

exports.main = async (event = {}) => {
  try {
    await assertAdmin();

    if (!event.bindingId) {
      return fail("bindingId is required");
    }
    if (!BINDING_STATUSES.includes(event.status)) {
      return fail("Invalid binding status");
    }

    const now = new Date();
    await db.collection("bindings").doc(event.bindingId).update({
      data: {
        status: event.status,
        updatedAt: now,
      },
    });

    return {
      success: true,
      data: {
        bindingId: event.bindingId,
        status: event.status,
        updatedAt: now,
      },
    };
  } catch (error) {
    return fail(error.message || "adminUpdateBindingStatus failed");
  }
};
