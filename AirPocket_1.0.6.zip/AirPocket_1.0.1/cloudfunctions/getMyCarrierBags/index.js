const cloud = require("wx-server-sdk");

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();
const _ = db.command;

const isCollectionMissing = (error) =>
  `${error.message || error.errMsg || error}`.toLowerCase().includes("not exist");

exports.main = async () => {
  const wxContext = cloud.getWXContext();
  const carrierId = wxContext.OPENID;

  if (!carrierId) {
    return {
      success: false,
      errMsg: "Unable to identify current user",
    };
  }

  try {
    const bagResult = await db
      .collection("bags")
      .where({ carrierId })
      .orderBy("createdAt", "desc")
      .limit(100)
      .get();

    const bags = bagResult.data || [];
    const bagIds = bags.map((bag) => bag._id).filter(Boolean);
    let bindings = [];

    if (bagIds.length) {
      try {
        const bindingResult = await db
          .collection("bindings")
          .where({
            bagId: _.in(bagIds),
          })
          .orderBy("createdAt", "desc")
          .limit(300)
          .get();
        bindings = bindingResult.data || [];
      } catch (error) {
        if (!isCollectionMissing(error)) {
          throw error;
        }
      }
    }

    const bindingsByBag = bindings.reduce((map, binding) => {
      if (!map[binding.bagId]) {
        map[binding.bagId] = [];
      }
      map[binding.bagId].push(binding);
      return map;
    }, {});

    const data = bags.map((bag) => {
      const bagBindings = bindingsByBag[bag._id] || [];
      const boundWeight = bagBindings.reduce(
        (sum, binding) => sum + Number(binding.requestedWeight || 0),
        0
      );
      return {
        ...bag,
        bindings: bagBindings,
        bindingCount: bagBindings.length,
        boundWeight: Math.round(boundWeight * 100) / 100,
      };
    });

    return {
      success: true,
      data,
    };
  } catch (error) {
    if (isCollectionMissing(error)) {
      return {
        success: true,
        data: [],
      };
    }
    return {
      success: false,
      errMsg: error.message || "getMyCarrierBags failed",
    };
  }
};
