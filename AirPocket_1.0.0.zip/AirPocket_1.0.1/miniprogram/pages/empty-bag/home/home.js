Page({
  goRelease() {
    wx.navigateTo({
      url: "/pages/empty-bag/release/release",
    });
  },

  goMyBag() {
    wx.navigateTo({
      url: "/pages/empty-bag/my/my",
    });
  },
});
