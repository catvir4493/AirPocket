const cloud = require("wx-server-sdk");

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();

exports.main = async (event = {}) => {
  if (!event.bagId) {
    return {
      success: false,
      errMsg: "bagId is required",
    };
  }

  try {
    const result = await db.collection("bags").doc(event.bagId).get();
    if (!result.data) {
      return {
        success: false,
        errMsg: "Bag not found",
      };
    }
    return {
      success: true,
      data: result.data,
    };
  } catch (error) {
    return {
      success: false,
      errMsg: error.message || "getBagDetail failed",
    };
  }
};
