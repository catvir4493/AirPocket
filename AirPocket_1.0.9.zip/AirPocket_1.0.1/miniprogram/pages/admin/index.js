const { formatDateTime, formatWeight } = require("../../utils/format");

const bagStatusLabels = {
  active: "可绑定",
  locked: "已锁定",
  closed: "已关闭",
  expired: "已过期",
};

const bindingStatusLabels = {
  pending: "待联系",
  locked: "已锁单",
  contacted: "已联系",
  picked_up: "已取货",
  packed: "已打包",
  delivered_to_carrier: "已送至带货者",
  completed: "已完成",
  cancelled: "已取消",
};

Page({
  data: {
    loading: false,
    errorMessage: "",
    summary: {
      bagCount: 0,
      bindingCount: 0,
    },
    bags: [],
    bagStatuses: [
      { value: "active", label: "Active" },
      { value: "locked", label: "Locked" },
      { value: "closed", label: "Closed" },
      { value: "expired", label: "Expired" },
    ],
    bindingStatuses: [
      { value: "pending", label: "待联系" },
      { value: "locked", label: "锁单" },
      { value: "contacted", label: "已联系" },
      { value: "picked_up", label: "已取货" },
      { value: "packed", label: "已打包" },
      { value: "delivered_to_carrier", label: "已送达" },
      { value: "completed", label: "已完成" },
      { value: "cancelled", label: "已取消" },
    ],
  },

  onShow() {
    this.fetchDashboard();
  },

  onPullDownRefresh() {
    this.fetchDashboard().finally(() => wx.stopPullDownRefresh());
  },

  async fetchDashboard() {
    this.setData({
      loading: true,
      errorMessage: "",
    });
    try {
      const resp = await wx.cloud.callFunction({
        name: "adminGetDashboard",
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "加载失败");
      }

      const bags = (result.data || []).map((bag) => ({
        ...bag,
        expanded: true,
        spaceTypeText: bag.spaceType === "fullCase" ? "整箱" : "散件",
        totalWeightText: formatWeight(bag.totalWeight),
        remainingWeightText: formatWeight(bag.remainingWeight),
        boundWeightText: formatWeight(bag.boundWeight || 0),
        statusText: bagStatusLabels[bag.status] || bag.status,
        createdAtText: formatDateTime(bag.createdAt),
        updatedAtText: formatDateTime(bag.updatedAt),
        bindings: (bag.bindings || []).map((binding) => ({
          ...binding,
          spaceTypeText: binding.spaceType === "fullCase" ? "整箱" : "散件",
          requestedWeightText: formatWeight(binding.requestedWeight),
          statusText: bindingStatusLabels[binding.status] || binding.status,
          createdAtText: formatDateTime(binding.createdAt),
          lockDeadlineText: formatDateTime(binding.lockDeadlineAt),
          lockedAtText: formatDateTime(binding.lockedAt),
          updatedAtText: formatDateTime(binding.updatedAt),
        })),
      }));

      this.setData({
        bags,
        summary: result.summary || {
          bagCount: bags.length,
          bindingCount: bags.reduce((sum, bag) => sum + (bag.bindings || []).length, 0),
        },
      });
    } catch (error) {
      this.setData({
        errorMessage: error.message || "加载失败",
      });
      wx.showToast({
        title: error.message || "加载失败",
        icon: "none",
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  toggleBag(event) {
    const { index } = event.currentTarget.dataset;
    this.setData({
      [`bags[${index}].expanded`]: !this.data.bags[index].expanded,
    });
  },

  async updateBagStatus(event) {
    const { id, status } = event.currentTarget.dataset;
    wx.showLoading({ title: "更新中..." });
    try {
      const resp = await wx.cloud.callFunction({
        name: "adminUpdateBagStatus",
        data: {
          bagId: id,
          status,
        },
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "更新失败");
      }
      wx.showToast({
        title: "已更新",
        icon: "success",
      });
      this.fetchDashboard();
    } catch (error) {
      wx.showToast({
        title: error.message || "更新失败",
        icon: "none",
      });
    } finally {
      wx.hideLoading();
    }
  },

  async updateBindingStatus(event) {
    const { id, status } = event.currentTarget.dataset;
    wx.showLoading({ title: "更新中..." });
    try {
      const resp = await wx.cloud.callFunction({
        name: "adminUpdateBindingStatus",
        data: {
          bindingId: id,
          status,
        },
      });
      const result = resp.result || {};
      if (!result.success) {
        throw new Error(result.errMsg || "更新失败");
      }
      wx.showToast({
        title: "已更新",
        icon: "success",
      });
      this.fetchDashboard();
    } catch (error) {
      wx.showToast({
        title: error.message || "更新失败",
        icon: "none",
      });
    } finally {
      wx.hideLoading();
    }
  },
});
