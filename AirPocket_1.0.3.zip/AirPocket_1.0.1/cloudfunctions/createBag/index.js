const cloud = require("wx-server-sdk");

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();

const normalizeList = (value) => {
  if (Array.isArray(value)) {
    return value.map((item) => `${item}`.trim()).filter(Boolean);
  }
  return `${value || ""}`
    .split(/[,，\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
};

const padBagNo = (seq) => `A${`${seq}`.padStart(4, "0")}`;

const fail = (errMsg) => ({
  success: false,
  errMsg,
});

const ensureCollection = async (name) => {
  try {
    await db.createCollection(name);
  } catch (error) {
    // Existing collections throw here; that is fine for this MVP bootstrap.
  }
};

exports.main = async (event = {}) => {
  const wxContext = cloud.getWXContext();
  const carrierId = wxContext.OPENID;
  const totalWeight = Number(event.totalWeight);

  if (!carrierId) {
    return fail("Unable to identify current user");
  }
  if (!`${event.fromCity || ""}`.trim()) {
    return fail("fromCity is required");
  }
  if (!`${event.toCity || ""}`.trim()) {
    return fail("toCity is required");
  }
  if (!`${event.departureDate || ""}`.trim()) {
    return fail("departureDate is required");
  }
  if (!Number.isFinite(totalWeight) || totalWeight <= 0) {
    return fail("totalWeight must be greater than 0");
  }

  const now = new Date();

  try {
    await ensureCollection("bags");
    await ensureCollection("counters");

    const result = await db.runTransaction(async (transaction) => {
      let seq = 1;
      const counterRef = transaction.collection("counters").doc("bags");

      try {
        const counter = await counterRef.get();
        seq = Number(counter.data.seq || 0) + 1;
        await counterRef.update({
          data: {
            seq,
            updatedAt: now,
          },
        });
      } catch (error) {
        seq = 1;
        await counterRef.set({
          data: {
            seq,
            updatedAt: now,
          },
        });
      }

      const bagNo = padBagNo(seq);
      const bagData = {
        bagNo,
        carrierId,
        carrierNickname: `${event.carrierNickname || ""}`.trim(),
        fromCity: `${event.fromCity || ""}`.trim(),
        toCity: `${event.toCity || ""}`.trim(),
        departureDate: `${event.departureDate || ""}`.trim(),
        flightNo: `${event.flightNo || ""}`.trim(),
        totalWeight,
        remainingWeight: totalWeight,
        availableVolume: `${event.availableVolume || ""}`.trim(),
        allowedItems: normalizeList(event.allowedItems || event.allowedItemsText),
        restrictedItems: normalizeList(event.restrictedItems || event.restrictedItemsText),
        note: `${event.note || ""}`.trim(),
        status: "active",
        createdAt: now,
        updatedAt: now,
      };

      const addResult = await transaction.collection("bags").add({
        data: bagData,
      });

      return {
        success: true,
        data: {
          _id: addResult._id,
          ...bagData,
        },
      };
    });

    return result;
  } catch (error) {
    return fail(error.message || "createBag failed");
  }
};
